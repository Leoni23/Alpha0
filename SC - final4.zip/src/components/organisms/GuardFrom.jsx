import React from 'react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

export const GuardFrom = ({ guard }) => {

    const navigate = useNavigate();
    const [error, setError] = useState(false);
    const [form, setForm] = useState({
        first_name: guard?.first_name ?? "",
        last_name: guard?.last_name ?? "",
        username: guard?.username ?? "",
        email: guard?.email ?? "",
        personal_phone: guard?.personal_phone ?? "",
        home_phone: guard?.home_phone ?? "",
        address: guard?.address ?? ""
    });
    const token = localStorage.getItem('token');

    const handleChange = (e) => {
        setForm({
            ...form,
            [e.target.name]: e.target.value
        });
    }

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (Object.values(form).includes("")) {
            console.log("error");
            setError(true)
            setTimeout(() => {
                setError(false)
            }, 2500);
            return;
        }

        try {
            console.log(guard)
            if (guard?.id) {
                await axios.post(
                    `http://127.0.0.1:8000/api/v1/guard/${guard.id}/update`,
                    { ...form }, { headers: { 'accept': 'application/json', 'authorization': token } }
                );
            } else {
                await axios.post(
                    `http://127.0.0.1:8000/api/v1/guard/create`,
                    { ...form }, { headers: { 'accept': 'application/json', 'authorization': token } }
                );
            }
            navigate('/guards');

        } catch (error) {
            console.log(error);
        }
    }


    return (
        <>
            <div className="panel-body">
                <form>
                    <fieldset>
                        <legend><i className="zmdi zmdi-account-box"></i> &nbsp; Información personal</legend>
                        <div className="container-fluid">
                            <div className="row">
                                <div className="col-xs-12 col-sm-6">
                                    <div className="form-group label-floating">
                                        <label className="control-label">Nombres *</label>
                                        <input pattern="[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{1,30}" className="form-control" type="text" name="nombre-reg" required="" L="30" />
                                    </div>
                                </div>
                                <div className="col-xs-12 col-sm-6">
                                    <div className="form-group label-floating">
                                        <label className="control-label">Apellidos *</label>
                                        <input pattern="[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{1,30}" className="form-control" type="text" name="apellido-reg" required="" L="30" />
                                    </div>
                                </div>
                                <div className="col-xs-12 col-sm-6">
                                    <div className="form-group label-floating">
                                        <label className="control-label">Teléfono</label>
                                        <input pattern="[0-9+]{1,15}" className="form-control" type="text" name="telefono-reg" L="15" />
                                    </div>
                                </div>
                                <div className="col-xs-12 col-sm-6">
                                    <div className="form-group label-floating">
                                        <label className="control-label">Telédono de Casa</label>
                                        <input pattern="[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{1,30}" className="form-control" type="text" name="ocupacion-reg" required="" L="30" />
                                    </div>
                                </div>
                                <div className="col-xs-12">
                                    <div className="form-group label-floating">
                                        <label className="control-label">Dirección</label>
                                        <textarea name="direccion-reg" className="form-control" rows="2" L="100"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </fieldset>
                    <br />
                    <fieldset>
                        <legend><i className="zmdi zmdi-key"></i> &nbsp; Datos de la cuenta</legend>
                        <div className="container-fluid">
                            <div className="row">
                                <div className="col-xs-12 col-sm-6">
                                    <div className="form-group label-floating">
                                        <label className="control-label">Nombre de usuario *</label>
                                        <input pattern="[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ]{1,15}" className="form-control" type="text" name="usuario-reg" required="" L="15" />
                                    </div>
                                </div>
                                <div className="col-xs-12 col-sm-6">
                                    <div className="form-group label-floating">
                                        <label className="control-label">E-mail</label>
                                        <input className="form-control" type="email" name="email-reg" L="50" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </fieldset>
                    <p className="text-center">
                        <button type="submit" className="btn btn-info btn-raised btn-sm"><i className="zmdi zmdi-floppy"></i> Guardar</button>
                    </p>
                </form>
            </div>

        </>

    )
}

import React from 'react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

export const JailForm = ({ jail }) => {

    const navigate = useNavigate();
    const [error, setError] = useState(false);
    const [form, setForm] = useState({
        first_name: jail?.first_name ?? "",
        last_name: jail?.last_name ?? "",
        username: jail?.username ?? "",
        email: jail?.email ?? "",
        personal_phone: jail?.personal_phone ?? "",
        home_phone: jail?.home_phone ?? "",
        address: jail?.address ?? ""
    });
    const token = localStorage.getItem('token');

    const handleChange = (e) => {
        setForm({
            ...form,
            [e.target.name]: e.target.value
        });
    }

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (Object.values(form).includes("")) {
            console.log("error");
            setError(true)
            setTimeout(() => {
                setError(false)
            }, 2500);
            return;
        }

        try {
            console.log(jail)
            if (jail?.id) {
                await axios.post(
                    `http://127.0.0.1:8000/api/v1/jail/${jail.id}/update`,
                    { ...form }, { headers: { 'accept': 'application/json', 'authorization': token } }
                );
            } else {
                await axios.post(
                    `http://127.0.0.1:8000/api/v1/jail/create`,
                    { ...form }, { headers: { 'accept': 'application/json', 'authorization': token } }
                );
            }
            navigate('/jails');

        } catch (error) {
            console.log(error);
        }
    }


    return (
        <>
            <div className="panel-body">
                <form>
                    <fieldset>
                        <legend><i className="bi bi-bank2"></i> &nbsp; Información de la cárcel</legend>
                        <div className="container-fluid">
                            <div className="row">
                                <div className="col-xs-12 col-sm-6">
                                    <div className="form-group label-floating">
                                        <label className="control-label">Nombres *</label>
                                        <input pattern="[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{1,30}" className="form-control" type="text" name="nombre-reg" required="" L="30" />
                                    </div>
                                </div>
                                <div className="col-xs-12 col-sm-6">
                                    <div className="form-group label-floating">
                                        <label className="control-label">Dirección *</label>
                                        <input pattern="[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{1,30}" className="form-control" type="text" name="apellido-reg" required="" L="30" />
                                    </div>
                                </div>
                                <div className="col-xs-12">
                                    <div className="form-group label-floating">
                                        <label className="control-label">Descripción</label>
                                        <textarea name="direccion-reg" className="form-control" rows="2" L="100"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </fieldset>
                    <p className="text-center">
                        <button type="submit" className="btn btn-info btn-raised btn-sm"><i className="zmdi zmdi-floppy"></i> Guardar</button>
                    </p>
                </form>
            </div>
        </>
    )
}

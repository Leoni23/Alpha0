import React from 'react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

export const WardForm = ({ ward }) => {

    const navigate = useNavigate();
    const [error, setError] = useState(false);
    const [form, setForm] = useState({
        first_name: ward?.first_name ?? "",
        last_name: ward?.last_name ?? "",
        username: ward?.username ?? "",
        email: ward?.email ?? "",
        personal_phone: ward?.personal_phone ?? "",
        home_phone: ward?.home_phone ?? "",
        address: ward?.address ?? ""
    });
    const token = localStorage.getItem('token');

    const handleChange = (e) => {
        setForm({
            ...form,
            [e.target.name]: e.target.value
        });
    }

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (Object.values(form).includes("")) {
            console.log("error");
            setError(true)
            setTimeout(() => {
                setError(false)
            }, 2500);
            return;
        }

        try {
            console.log(ward)
            if (ward?.id) {
                await axios.post(
                    `http://127.0.0.1:8000/api/v1/ward/${ward.id}/update`,
                    { ...form }, { headers: { 'accept': 'application/json', 'authorization': token } }
                );
            } else {
                await axios.post(
                    `http://127.0.0.1:8000/api/v1/ward/create`,
                    { ...form }, { headers: { 'accept': 'application/json', 'authorization': token } }
                );
            }
            navigate('/wards');

        } catch (error) {
            console.log(error);
        }
    }


    return (
        <>
            <div className="panel-body">
                <form>
                    <fieldset>
                        <legend><i className="bi bi-view-stacked"></i> &nbsp; Información del pabellon</legend>
                        <div className="container-fluid">
                            <div className="row">
                                <div className="col-xs-12 col-sm-6">
                                    <div className="form-group label-floating">
                                        <label className="control-label">Nombre del pabellon *</label>
                                        <input pattern="[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{1,30}" className="form-control" type="text" name="nombre-reg" required="" L="30" />
                                    </div>
                                </div>
                                <div className="col-xs-12 col-sm-6">
                                    <div className="form-group label-floating">
                                        <label className="control-label">Código *</label>
                                        <input pattern="[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{1,30}" className="form-control" type="text" name="codigo-reg" required="" L="30" />
                                    </div>
                                </div>
                                <div className="col-xs-12 col-sm-6">
                                    <div className="form-group label-floating">
                                        <label className="control-label">Tipo</label>
                                        <input pattern="[0-9+]{1,15}" className="form-control" type="text" name="tipo-reg" L="15" />
                                    </div>
                                </div>
                                <div className="col-xs-12 col-sm-6">
                                    <div className="form-group label-floating">
                                        <label className="control-label">Capacidad</label>
                                        <input pattern="[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{1,30}" className="form-control" type="text" name="capacidad-reg" required="" L="30" />
                                    </div>
                                </div>
                                <div className="col-xs-12">
                                    <div className="form-group label-floating">
                                        <label className="control-label">Descripción</label>
                                        <textarea name="direccion-reg" className="form-control" rows="2" L="100"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </fieldset>
                    <br />
                        <p className="text-center">
                        <button type="submit" className="btn btn-info btn-raised btn-sm"><i className="zmdi zmdi-floppy"></i> Guardar</button>
                    </p>
                </form>
            </div>

        </>

    )
}

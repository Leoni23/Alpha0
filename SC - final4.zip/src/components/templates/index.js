export { AuthTemplate } from './AuthTemplate';

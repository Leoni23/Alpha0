import { createContext } from 'react';


// Uso de la creación de un useContext para el manejo de autenticación
export const AuthContext = createContext();
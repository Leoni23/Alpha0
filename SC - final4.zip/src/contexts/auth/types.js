

// Establecer los dos estados para la aplicación 
export const types = {
    login: '[Auth] Login',

    logout: '[Auth] Logout',
}

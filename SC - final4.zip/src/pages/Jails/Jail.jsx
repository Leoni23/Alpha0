import React from "react";

import { Link, Outlet, useLocation } from "react-router-dom";
import { useNavigate } from "react-router-dom";

export const Jails = () => {
	const navigate = useNavigate();

	const location = useLocation();
	const urlActual = location.pathname;

	console.log();
	return (
		<>
			<div className="container-fluid">
				<div className="page-header">
					<h1 className="text-titles">
						<i className="bi bi-bank2"></i> Administración{" "}
						<small>DE CÁRCELES</small>
					</h1>
				</div>
				<p className="lead">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse
					voluptas reiciendis tempora voluptatum eius porro ipsa quae voluptates
					officiis sapiente sunt dolorem, velit quos a qui nobis sed,
					dignissimos possimus!
				</p>
			</div>

			<div className="container-fluid">
				<ul className="breadcrumb breadcrumb-tabs">
					<li>
						<Link to="/Dashboard/jails" className={`${urlActual === '/Dashboard/jails' ? ' btn-success': 'btn-outline-success'} btn `}>
							<i className="bi bi-list-check"></i> &nbsp;LISTA DE CÁRCELES
						</Link>
					</li>
					<li>
						<Link to="/Dashboard/jails/create" className={`${urlActual === '/Dashboard/jails/create' ? ' btn-info': 'btn-outline-info'} btn `}>
							<i className="zmdi zmdi-plus"></i> &nbsp; NUEVA CÁRCEL
						</Link>
					</li>
				</ul>
			</div>
			<Outlet />
		</>
	);
};

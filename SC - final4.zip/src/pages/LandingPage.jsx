import React from 'react'
import { useNavigate } from 'react-router-dom'

export const LandingPage = () => 
{
  const navigate = useNavigate()
  return (
    <div className=''>
      <div>
        <button className='' onClick={()=>{navigate("/login")}}> Bienvenidos</button>
      </div>
    </div>
  )
}



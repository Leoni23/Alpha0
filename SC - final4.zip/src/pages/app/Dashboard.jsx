import React from 'react'

import { Link, Outlet, useLocation } from 'react-router-dom'
import { useNavigate } from "react-router-dom";
import React, { useContext } from 'react';
import { AuthContext } from '../../contexts';


export const Dashboard = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const urlActual = location.pathname;
    const { user } = useContext(AuthContext);

    return (
        <>
            <section className="full-box dashboard-sideBar" >
                <div className="full-box dashboard-sideBar-bg btn-menu-dashboard"></div>
                <div className="full-box dashboard-sideBar-ct">

                    <div className="full-box text-uppercase text-center text-titles dashboard-sideBar-title">
                        Sistema Carcelario <i className="zmdi zmdi-close btn-menu-dashboard visible-xs"></i>
                    </div>

                    <div className="full-box dashboard-sideBar-UserInfo">
                        <figure className="full-box">
                            <img src="" alt="UserIcon" />
                            {<figcaption className="text-center text-titles">User Name</figcaption>}
                        </figure>
                        <ul className="full-box list-unstyled text-center">
                            <li>
                                <Link to="/Dashboard/profile" title="Mis datos">
                                    <i className="zmdi zmdi-account-circle"></i>
                                </Link>
                            </li>
                            <li>
                                <Link to="/login" className="">
                                    <i className="zmdi zmdi-power"></i>
                                </Link>
                            </li>
                        </ul>
                    </div>

                    <ul className="list-unstyled full-box dashboard-sideBar-Menu">
                        <li>
                            <Link to='/Dashboard/home'>
                                <i className="zmdi zmdi-view-dashboard zmdi-hc-fw"></i> Inicio
                            </Link>
                        </li>
                        <li>
                            <a href="" className="btn-sideBar-SubMenu ">
                                <i className="zmdi zmdi-case zmdi-hc-fw"></i> Administración <i className="zmdi zmdi-caret-down pull-right"></i>
                            </a>
                            <ul className="list-unstyled full-box dashboard-sideBar-Menu">
                                <li>
                                    <Link to="/Dashboard/report"><i className="bi bi-file-earmark-richtext-fill"></i> Reporte</Link>
                                </li>
                                <li>
                                    <Link to="/Dashboard/jails"><i className="bi bi-bank2"></i> Carceles</Link>
                                </li>
                                <li>
                                    <Link to="/Dashboard/wards"><i className="bi bi-view-stacked"></i> Pabellones</Link>
                                </li>
                                <li>
                                    <Link to="/Dashboard/assignment"><i className="bi bi-pass-fill"></i> Asignacion</Link>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="" className="btn-sideBar-SubMenu">
                                <i className="zmdi zmdi-account-add "></i> Usuarios <i className="zmdi zmdi-caret-down pull-right"></i>
                            </a>
                            <ul className="list-unstyled full-box dashboard-sideBar-Menu">
                                <li>
                                    <Link to="/Dashboard/directors" href="" className=''><i className="bi bi-person-lines-fill"></i> Directores</Link>
                                </li>
                                <li>
                                    <Link to="/Dashboard/guards"><i className="bi bi-shield-shaded "></i> Guardias</Link>
                                </li>
                                <li>
                                    <Link to="/Dashboard/prisoners"><i className="bi bi-incognito"></i> Prisioneros</Link>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </section>

            {/* <!-- Content page--> */}
            <section className="full-box dashboard-contentPage bg-light">
                {/* <!-- NavBar --> */}
                <nav className="full-box dashboard-Navbar bg-black">
                    <ul className="full-box list-unstyled text-right">
                        <li className="pull-left">
                            <a href="" className="btn-menu-dashboard"><i class="zmdi zmdi-more-vert"></i></a>
                        </li>
                    </ul>
                </nav>
                <Outlet />
            </section>
        </>
    )
}


import React from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";

export const Home = () => {
    const navigate = useNavigate();

    return (
        <>
            <div class="container-fluid">
                <div class="page-header">
                    <h1 class="text-titles"><i class="bi bi-people-fill"></i> Informacion <small>DE USUARIOS</small></h1>
                </div>
            </div>
            <div class="full-box text-center">
                <Link to="/Dashboard/directors" class="full-box tile ">
                    <div class="full-box tile-title text-center text-titles text-uppercase bg-dark">
                        Directores
                    </div>
                    <div class="full-box tile-icon text-center ">
                        <i class="bi bi-person-lines-fill text-dark"></i>
                    </div>
                    <div class="full tile-number text-titles text-dark">
                        <p class="full-box">7</p>
                        <small>Registrados</small>
                    </div>
                </Link>
                <Link to="/Dashboard/guards" class="full-box tile ">
                    <div class="full-box tile-title text-center text-titles text-uppercase bg-dark">
                        Guardias
                    </div>
                    <div class="full-box tile-icon text-center ">
                        <i class="bi bi-shield-shaded text-dark"></i>
                    </div>
                    <div class="full tile-number text-titles text-dark">
                        <p class="full-box">7</p>
                        <small>Registrados</small>
                    </div>
                </Link>
                <Link to="/Dashboard/prisoners" class="full-box tile ">
                    <div class="full-box tile-title text-center text-titles text-uppercase bg-dark">
                        Prisioneros
                    </div>
                    <div class="full-box tile-icon text-center ">
                        <i class="bi bi-incognito text-dark"></i>
                    </div>
                    <div class="full tile-number text-titles text-dark">
                        <p class="full-box">7</p>
                        <small>Registrados</small>
                    </div>
                </Link>
            </div>

            <div class="container-fluid">
                <div class="page-header">
                    <h1 class="text-titles"><i class="zmdi zmdi-case zmdi-hc-fw"></i> Informacion <small>DEL SISTEMA</small></h1>
                </div>
            </div>
            <div class="full-box text-center">
                <Link to="/Dashboard/jails" class="full-box tile ">
                    <div class="full-box tile-title text-center text-titles text-uppercase bg-dark">
                        CARCELES
                    </div>
                    <div class="full-box tile-icon text-center ">
                        <i class="bi bi-bank2 text-dark"></i>
                    </div>
                    <div class="full tile-number text-titles text-dark">
                        <p class="full-box">5</p>
                        <small>Registrados</small>
                    </div>
                </Link>
                <Link to="/Dashboard/report" class="full-box tile ">
                    <div class="full-box tile-title text-center text-titles text-uppercase bg-dark">
                        Reportes
                    </div>
                    <div class="full-box tile-icon text-center ">
                        <i class="bi bi-file-earmark-richtext-fill text-dark"></i>
                    </div>
                    <div class="full tile-number text-titles text-dark">
                        <p class="full-box">7</p>
                        <small>Registrados</small>
                    </div>
                </Link>
            </div>

        </>)
};
import React from 'react'
import { useNavigate } from "react-router-dom";
import { AuthContext } from '../../contexts'; 

export const Forgot_password = () => 
{
    /* const { login } = useContext(AuthContext); */
    const navigate = useNavigate();

    /* const [email, setEmail] = useState('')
    const [password, setPassword] = useState('') */

    /* onst onLogin = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post(
                'https://fivesprint.herokuapp.com/api/v1/login',
                { email, password },
                { headers: { 'accept': 'application/json' } }
            )
            const {access_token, token_type, user} = response.data.data 
            login(user, `${token_type} ${access_token}`);   
            navigate('/');       
        } catch (error) {
            console.log(error.response.data.message, 'error');
            setEmail('');
            setPassword('');
        } */
    
    return (
        <>
        <p className="text-center text-light text-uppercase">Recuperar contraseña</p>
		<form  method="" autocomplete="on" className="logInForm bg-dark text-dark">
			<p className="text-center text-light "><i className="zmdi zmdi-account-circle zmdi-hc-5x"></i></p>
			<p className="text-center text-light text-uppercase">Recuperar contraseña</p>
			<div className="form-group label-floating">
                <label className="control-label" >Correo</label>
                <input 
                className="form-control" 
                id='email'
                name='email'
                type='email'
                /* value={email} */
                placeholder='Ingresa tu correo'
                maxLength="35"
                required
                autoFocus
                /* onChange={e => setEmail(e.target.value) *//>
                <p className="help-block text-muted">Escribe tú Correo</p>
			</div>
		
			<div className="form-group text-center">
			</div>
            <a onClick={()=>{navigate("/login")}} className="btn btn-outline-primary btn-block">
                Enviar correo
            </a>
            {/* <Button name='Sing in' styles='w-3/5' /> */}
        <div className="text-center ">
            <a className="small text-info" href="#">Regresar</a>
        </div>
		</form>
	</>
    )
}

import React, { useContext, useState } from 'react';
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import { AuthContext } from '../../contexts'; 

export const Login = () => 
{
    const { login } = useContext(AuthContext); 
    const navigate = useNavigate();

    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('') 

    const onLogin = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post(
                'https://fivesprint.herokuapp.com/api/v1/login',
                { email, password },
                { headers: { 'accept': 'application/json' } }
            )
            const {access_token, token_type, user} = response.data.data 
            login(user, `${token_type} ${access_token}`);   
            navigate('/Dashboard/home');       
        } catch (error) {
            console.log(error.response.data.message, 'error');
            setEmail('');
            setPassword('');
        } 
    }

    return (
        <>
		<form autocomplete="on" className="logInForm bg-dark text-dark" onSubmit={onLogin} >
			<p className="text-center text-light "><i className="zmdi zmdi-account-circle zmdi-hc-5x"></i></p>
			<p className="text-center text-light text-uppercase">Inicia sesión con tu cuenta</p>
			<div className="form-group label-floating">
                <label className="control-label" >Correo</label>
                <input 
                className="form-control" 
                id='email'
                name='email'
                type='email'
                value={email}
                placeholder='Ingresa tu correo'
                maxLength="35"
                required
                autoFocus
                onChange={e => setEmail(e.target.value) } />
                <p className="help-block text-muted">Escribe tú Correo</p>
			</div>
			<div className="form-group label-floating">
                <label className="control-label">Contraseña</label>
                <input 
                className="form-control" 
                id='password'
                name='password'
                type='password'
                value={password}
                placeholder='Ingresa tu contraseña'
                required
                onChange={e => setPassword(e.target.value) }/>
                <p className="help-block text-muted">Escribe tú contraseña</p>
			</div>
			<div className="form-group text-center">
			</div>
            <a type="submit" className="btn btn-primary btn-block">
                Iniciar Sesión
            </a>
            {/* <Button name='Sing in' styles='w-3/5' /> */}
            
            <div className="text-center">
            <a onClick={()=>{navigate("/forgot_password")}} className="small text-info" href="#">Olvide me contraseña?</a>
            </div>
		</form>
	</>
    );
}

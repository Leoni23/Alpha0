import React from "react";

import { Link, Outlet, useLocation } from "react-router-dom";
import { useNavigate } from "react-router-dom";

export const Directors = () => {
	const navigate = useNavigate();

	const location = useLocation();
	const urlActual = location.pathname;

	console.log(Directors);
	return (
		<>
			<div className="container-fluid">
				<div className="page-header">
					<h1 className="text-titles">
						<i className="bi bi-person-lines-fill"></i> Usuarios{" "}
						<small>DIRECTOR</small>
					</h1>
				</div>
				<p className="lead">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse
					voluptas reiciendis tempora voluptatum eius porro ipsa quae voluptates
					officiis sapiente sunt dolorem, velit quos a qui nobis sed,
					dignissimos possimus!
				</p>
			</div>

			<div className="container-fluid">
				<ul className="breadcrumb breadcrumb-tabs">
					<li>
						<Link to="/Dashboard/directors" className={`${urlActual === '/Dashboard/directors' ? ' btn-success': 'btn-outline-success'} btn `}>
							<i className="bi bi-list-check"></i> &nbsp;LISTA DE DIRECTORES
						</Link>
					</li>
					<li>
						<Link to="/Dashboard/directors/create" className={`${urlActual === '/Dashboard/directors/create' ? ' btn-info': 'btn-outline-info'} btn `}>
							<i className="zmdi zmdi-plus"></i> &nbsp; NUEVO DIRECTOR
						</Link>
					</li>
					<li>
						<a href="client-search.html" className="btn btn-primary">
							<i className="zmdi zmdi-search"></i> &nbsp; BUSCAR DIRECTOR
						</a>
					</li>
				</ul>
			</div>
			<Outlet />
		</>
	);
};

import React from 'react';
import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { PrisonerForm } from '../../components/organisms/PrisonerForm';

export const UpdatePrisoner = () => {
    const { id } = useParams();
    const [prisoner, setPrisoner] = useState({});
    const token = localStorage.getItem('token');

    useEffect(() => {
        const getPrisoner = async () => {
            try {
                const response = await axios.get(
                    `http://127.0.0.1:8000/api/v1/prisionero/${id}`,
                    { headers: { 'accept': 'application/json', 'authorization': token } }
                )
                const user = { ...response.data.data.user, id }
                setPrisoner(user);
                console.log(user);
            } catch (error) {
                console.log(error);
            }
        }
        getPrisoner
    }, [])

    return (
        <div>
            <div className="container-fluid">
                <div className="panel panel-info">
                    <div className="panel-heading bg-info">
                        <h3 className="panel-title text-light"><i className="bi bi-pencil-square"></i> &nbsp; EDITAR PRISIONERO</h3>
                    </div>
                    <PrisonerForm />
                </div>
            </div>
            {/* COPIAR LOGICA */}
            <h1 className='font-black text-4xl text-sky-900'>Prisionero</h1>
            <hr className='mt-3' />
            {
                Object.keys(prisoner).length > 0 ?
                    (
                        <PrisonerForm prisoner={prisoner} />
                    )
                    :
                    (
                        <p className="bg-yellow-600 border-t border-b border-yellow-900 text-white px-4 py-3 m-5 text-center rounded-lg">No data for this prisionero</p>
                    )
            }
        </div>
    )
}

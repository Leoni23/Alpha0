import React from "react";

import { Link, Outlet, useLocation } from "react-router-dom";
import { useNavigate } from "react-router-dom";

export const Wards = () => {
	const navigate = useNavigate();

	const location = useLocation();
	const urlActual = location.pathname;

	console.log(Wards);
	return (
		<>
			<div className="container-fluid">
				<div className="page-header">
					<h1 className="text-titles">
						<i className="bi bi-view-stacked"></i> Administrar{" "}
						<small>PABELLONES</small>
					</h1>
				</div>
				<p className="lead">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse
					voluptas reiciendis tempora voluptatum eius porro ipsa quae voluptates
					officiis sapiente sunt dolorem, velit quos a qui nobis sed,
					dignissimos possimus!
				</p>
			</div>

			<div className="container-fluid">
				<ul className="breadcrumb breadcrumb-tabs">
					<li>
						<Link to="/Dashboard/wards" className={`${urlActual === '/Dashboard/wards' ? ' btn-success': 'btn-outline-success'} btn `}>
							<i className="bi bi-list-check"></i> &nbsp;LISTA DE PABELLONES
						</Link>
					</li>
					<li>
						<Link to="/Dashboard/wards/create" className={`${urlActual === '/Dashboard/wards/create' ? ' btn-info': 'btn-outline-info'} btn `}>
							<i className="zmdi zmdi-plus"></i> &nbsp; NUEVO PABELLON
						</Link>
					</li>
					<li>
						<Link to="/Dashboard/jails" className="btn btn-outline-secondary">
							<i className="bi bi-arrow-left-circle"></i> &nbsp; Regresar
						</Link>
					</li>
				</ul>
			</div>
			<Outlet />
		</>
	);
};
